/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssalesgui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author motso
 */

interface IProductCalculations {
    double GetVat();
    double GetCommission();
    double GetTotal();
}

class ProductCalculations implements IProductCalculations {
    private double productPrice;
    private double vat;
    private double commission;
    private double total;

    public ProductCalculations(double productPrice) {
        this.productPrice = productPrice;
        this.vat = productPrice * 0.15;
        this.commission = productPrice * 0.05;
        // Total is Price + VAT + Commission
        this.total = productPrice + this.vat + this.commission; 
    }

    @Override
    public double GetVat() {
        return vat;
    }

    @Override
    public double GetCommission() {
        return commission;
    }

    @Override
    public double GetTotal() {
        return total;
    }
}



public class MattressSalesGUI extends JFrame {

    private JTextField txtCustomerName;
    private JComboBox<String> cmbProductName;
    private JTextField txtPrice;
    private JButton btnProcess;

    public MattressSalesGUI() {
        setTitle("Product App");
        setSize(450, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Menu Bar
        JMenuBar menuBar = new JMenuBar();

        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem processItem = new JMenuItem("Process");
        processItem.addActionListener(e -> processSale());
        
        JMenuItem clearItem = new JMenuItem("Clear");
        clearItem.addActionListener(e -> clearForm());
        
        toolsMenu.add(processItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        //Form
        JPanel formPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Customer Name
        gbc.gridx = 0; gbc.gridy = 0;
        formPanel.add(new JLabel("Customer Name:"), gbc);
        gbc.gridx = 1; gbc.gridy = 0;
        txtCustomerName = new JTextField(20);
        formPanel.add(txtCustomerName, gbc);

        // Select Product
        gbc.gridx = 0; gbc.gridy = 1;
        formPanel.add(new JLabel("Select Product:"), gbc);
        gbc.gridx = 1; gbc.gridy = 1;
        String[] products = {"Cosy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};
        cmbProductName = new JComboBox<>(products);
        formPanel.add(cmbProductName, gbc);

        // to enter price
        gbc.gridx = 0; gbc.gridy = 2;
        formPanel.add(new JLabel("Enter Price:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        txtPrice = new JTextField(20);
        formPanel.add(txtPrice, gbc);

        // Process Button
        gbc.gridx = 1; gbc.gridy = 3;
        btnProcess = new JButton("PROCESS");
        btnProcess.addActionListener(e -> processSale());
        formPanel.add(btnProcess, gbc);

        add(formPanel, BorderLayout.CENTER);
    }

    //Processing Logic
    private void processSale() {
        try {
            String customerName = txtCustomerName.getText().trim();
            String product = (String) cmbProductName.getSelectedItem();
            
            // Validate input
            if (customerName.isEmpty() || txtPrice.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            double price = Double.parseDouble(txtPrice.getText().trim());

            // Calculate using the separate class
            ProductCalculations calc = new ProductCalculations(price);
            
            double vat = calc.GetVat();
            double commission = calc.GetCommission();
            double total = calc.GetTotal();

            // String formating 
            String message = String.format(
                "Customer Name: %s\nProduct: %s\nVAT: R %.1f\nCOMMISSION: R %.1f\nTOTAL: R %.1f",
                customerName, product, vat, commission, total
            );

            // Show Dialog
            JOptionPane.showMessageDialog(this, message, "Message", JOptionPane.INFORMATION_MESSAGE);

            // Save to file
            saveToFile(message);

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid number for the price.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // --- File Saving
    private void saveToFile(String message) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt", true))) {
            // Appending to file so multiple sales are recorded
            writer.write("DATA LOG\n");
            writer.write("**************************************\n");
            writer.write(message + "\n");
            writer.write("**************************************\n\n");
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error saving to file.", "File Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // to clear the form
    private void clearForm() {
        txtCustomerName.setText("");
        txtPrice.setText("");
        cmbProductName.setSelectedIndex(0);
        txtCustomerName.requestFocus();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new MattressSalesGUI().setVisible(true);
        });
    }
}
