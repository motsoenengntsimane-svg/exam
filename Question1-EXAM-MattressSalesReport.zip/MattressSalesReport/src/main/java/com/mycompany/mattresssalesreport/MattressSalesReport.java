/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mattresssalesreport;

import java.util.*;

/**
 *
 * @author motso
 */

interface IProduct{
    int GetTotalProductsSold();
    double GetAverageProductSold();
    String GetMostPopularProduct();
}

class Product implements IProduct {
    private int[][] salesData;
    private String[] productNames;
    private int totalSold;
    private double averageSold;
    private String mostPopular;

    // Constructor to initialize the data
    public Product(int[][] salesData, String[] productNames) {
        this.salesData = salesData;
        this.productNames = productNames;
        calculateStats(); // Calculate values on instantiation
    }

    private void calculateStats() {
        int finalTotal = 0;
        int[] productTotals = new int[productNames.length];
        int maxIndex = 0;

        for (int i = 0; i < salesData.length; i++) {
            int currentTotal = 0;
            for (int j = 0; j < salesData[i].length; j++) {
                currentTotal += salesData[i][j];
            }
            productTotals[i] = currentTotal;
            finalTotal += currentTotal;

            if (productTotals[i] > productTotals[maxIndex]) {
                maxIndex = i;
            }
        }

        this.totalSold = finalTotal;
        this.averageSold = (double) finalTotal / productNames.length;
        // Formatting the most popular string to match the sample output
        this.mostPopular = productNames[maxIndex].replace(" mattresses", "") + " (" + productTotals[maxIndex] + ")";
    }

    @Override
    public int GetTotalProductsSold() {
        return totalSold;
    }

    @Override
    public double GetAverageProductSold() {
        return averageSold;
    }

    @Override
    public String GetMostPopularProduct() {
        return mostPopular;
    }
}

class PrintProduct {
    public void printReport(Product product) {
        System.out.println("\nPRODUCT SALES REPORT - 2026");
        System.out.println("**************************************************");
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
        
        // Formatting average to 0 decimal places as per the screenshot
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductSold());
        
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct());
    }
}

public class MattressSalesReport {
    
        public static void main(String[] args) {
            try (Scanner scanner = new Scanner(System.in)) {
                String[] productNames = {
                    "Cozy Nights Monarch mattresses",
                    "Restonic Barbados mattresses",
                    "Sealy Posturepedic mattresses"};
                
                int[][] salesData = new int[3][3];
                
                // Input Loop
                for (int i = 0; i < productNames.length; i++) {
                    for (int j = 0; j < 3; j++) {
                        System.out.print("Enter number of sales for month " + (j + 1) + " for " + productNames[i] + ": ");
                        salesData[i][j] = scanner.nextInt();
                    }
                }
                
                // Instantiate Product and PrintProduct classes
                Product product = new Product(salesData, productNames);
                PrintProduct printer = new PrintProduct();
                
                // Print the report
                printer.printReport(product);
            }
            }
        }
    
