/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.mattresssalesreport;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author motso
 */
public class ProductTest {

    // data 
    private final int[][] sampleSalesData = {
        {25, 18, 20}, // Cozy Nights (Total: 63)
        {15, 10, 12}, // Restonic (Total: 37)
        {18, 15, 20}  // Sealy (Total: 53)
    };
    
    private final String[] sampleProductNames = {
        "Cozy Nights Monarch mattresses",
        "Restonic Barbados mattresses",
        "Sealy Posturepedic mattresses"
    };

    @Test
    public void GetTotalProductSales_WithValidData_ReturnsCorrectValue() {
        // Arrange
        Product product = new Product(sampleSalesData, sampleProductNames);
        
        // Act
        int expectedTotal = 153; // 63 + 37 + 53
        int actualTotal = product.GetTotalProductsSold();
        
        // Assert
        assertEquals(expectedTotal, actualTotal, "The total products sold should be 153.");
    }

    @Test
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        // Arrange
        Product product = new Product(sampleSalesData, sampleProductNames);
        
        // Act
        double expectedAverage = 51.0; // 153 / 3
        double actualAverage = product.GetAverageProductSold();
        
        // Assert
        assertEquals(expectedAverage, actualAverage, 0.01, "The average should be 51.0.");
    }
}
